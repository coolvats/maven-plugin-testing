Each sub-directory here contains "preset" Hudson home directories that are often useful
for tests. See individual readme.txt for what each data set represents.

These directories are zipped up into the test-harness jar during a build by package.groovy,
and from test case